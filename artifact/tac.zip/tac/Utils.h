#ifndef UTILS_H
#define UTILS_H

#include "Headers.h"
#include "Constants.h"

string toString(int a) {
	ostringstream ost;
	ost << a;
	string str(ost.str());
	return str;
}	

string toString(double a) {
	ostringstream ost;
	ost << a;
	string str(ost.str());
	return str;
}

string toString(SourceLocation loc) {
	return loc.printToString(rewriter.getSourceMgr());
}

string FDErrorStr(string var, string tag, string type) {
	string ret("");
	string tagNum = tag;
	if (tag[tag.size() - 1] == '_') tagNum = tag.substr(0, tag.size() - 1);
	ret = "\n" + printError + type + "(\"" + var + "_tag" + tag + "\", &" + var + ", " + tagNum + ");";
	return ret;
}

string FDReduceStr(string var, string tag, string type) {
	string ret("");
	string tagNum = tag;
	if (tag[tag.size() - 1] == '_') tagNum = tag.substr(0, tag.size() - 1);
	ret = "\n" + printReduce + type + "(&" + var + ", " + tagNum + ");";
	return ret;
}

string FDResumeStr(string var, string tag, string type) {
	string ret("");
	ret = "\n" + printResume + type + "(&" + var + ", " + tag + ");";
	return ret;
}

void saveTagCountToLog() {
	ofstream out(logfile);
	out << tagCount;
	out.close();
}


#define SL_INVALID 0
#define SL_GREAT 1
#define SL_LESS 2
#define SL_EQUAL 3

int SLcmp(SourceLocation a, SourceLocation b) {
	PresumedLoc PLoca = rewriter.getSourceMgr().getPresumedLoc(a);
	PresumedLoc PLocb = rewriter.getSourceMgr().getPresumedLoc(b);
	if (PLoca.getFilename() != PLocb.getFilename())
		return SL_INVALID;
	if (PLoca.getLine() > PLocb.getLine())
		return SL_GREAT;
	else if (PLoca.getLine() < PLocb.getLine())
		return SL_LESS;
	else {
		if (PLoca.getColumn() > PLocb.getColumn())
			return SL_GREAT;
		else if (PLoca.getColumn() < PLocb.getColumn())
			return SL_LESS;
		else return SL_EQUAL;
	}
}

SourceLocation getPureLocFirst(SourceLocation loc) {
	cout << "before" << endl;
	loc.dump(rewriter.getSourceMgr());
	cout << endl;
	if (loc.isMacroID()) {
		pair< SourceLocation, SourceLocation > expansionRange = 
			rewriter.getSourceMgr().getImmediateExpansionRange(loc);
		cout << "after" << endl;
		expansionRange.first.dump(rewriter.getSourceMgr());
		cout << endl;
		return expansionRange.first;
	}
	return loc;
}

SourceLocation getPureLocSecond(SourceLocation loc) {
	if (loc.isMacroID()) {
		pair< SourceLocation, SourceLocation > expansionRange = 
			rewriter.getSourceMgr().getImmediateExpansionRange(loc);
		return expansionRange.second;
	}
	return loc;
}

// Deal with macro
SourceRange getSourceRange(SourceLocation startLoc, SourceLocation endLoc) {
	startLoc = getPureLocFirst(startLoc);
	endLoc = getPureLocSecond(endLoc);
	SourceRange expandedLoc(startLoc, endLoc);
	return expandedLoc;
}

SourceRange getSourceRange(Stmt * stmt) {
	assert(stmt != NULL);
	return getSourceRange(stmt->getLocStart(), stmt->getLocEnd());
}

SourceRange getSourceRange(VarDecl * decl) {
	assert(decl != NULL);
	return getSourceRange(decl->getLocStart(), decl->getLocEnd());
}

bool isSameFile(SourceLocation srcLoc) {
	if (rewriter.getSourceMgr().getFileID(getPureLocFirst(srcLoc)) == rewriter.getSourceMgr().getMainFileID()) return true;
	else return false;
}

bool isMacro(Stmt * stmt) {
	if (stmt->getLocStart().isMacroID() || stmt->getLocEnd().isMacroID()) {
		return true;
	}
	return false;
}

bool isLiteral(Stmt * stmt) {
	if (IntegerLiteral * specExpr = dyn_cast<IntegerLiteral>(stmt)) return true;
	if (FloatingLiteral * specExpr = dyn_cast<FloatingLiteral>(stmt)) return true;
	if (CharacterLiteral * specExpr = dyn_cast<CharacterLiteral>(stmt)) return true;
	if (ImaginaryLiteral * specExpr = dyn_cast<ImaginaryLiteral>(stmt)) return true;
	if (StringLiteral * specExpr = dyn_cast<StringLiteral>(stmt)) return true;
	return false;
}
#endif