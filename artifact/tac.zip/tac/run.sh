#!/bin/sh

# Our scripts for instrumentation for GLIBC,
# also an example of how to use run_ind.sh
cd ~/work/glibc-2.19/sysdeps/ieee754/dbl-64/
files=`ls e_*.c`
cd -

for file in $files
do
	./run_ind.sh ~/work/glibc-2.19/sysdeps/ieee754/dbl-64/$file > output$file 2>&1
done
