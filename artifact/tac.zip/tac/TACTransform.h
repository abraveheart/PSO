#ifndef TACTRANSFORM_H
#define TACTRANSFORM_H

#include "Headers.h"
#include "Constants.h"
#include "Utils.h"

class VarInfo
{
public:
	VarInfo()
	{
		this->var = "";
		this->fpVar = "";
	}
	VarInfo(string var)
	{
		this->var = var;
		fpVar = "";
	}
	VarInfo(string var, string fpVar)
	{
		this->var = var;
		this->fpVar = fpVar;
	}
	VarInfo(string var, string fpVar, vector<string> & vars)
	{
		this->var = var;
		this->fpVar = fpVar;
		this->vars = vars;
	}
	string var;
	string fpVar; // for union (mynumber), when access mynumber.i[], compute error for mynumber.d
	vector<string> vars;
};


class TACTransformVisitor : public RecursiveASTVisitor<TACTransformVisitor> {
private:
	ASTContext *astContext; // used for getting additional AST info

	SourceLocation beginLoc;

	bool ignore;

	int varCount;

	int biExprCount;

	int callExprCount;

	VarInfo lastNewVar;

	vector<string> stats;

	int countBinaryOp(Stmt *stmt) {
		if (stmt == NULL) return 0;
		Stmt::child_iterator it = stmt->child_begin();
		int num = 0;
		for(; it != stmt->child_end(); it++) {
			num += countBinaryOp(*it);
		}
		if (isa<BinaryOperator>(*stmt)) {
			num++;
		}
		return num;
	}

	VarInfo getVar(Expr *expr) {
		Expr *subExpr;
		if (BinaryOperator *specExpr = dyn_cast<BinaryOperator>(expr)) {
			VarInfo varInfo = threeAddrCode(specExpr);
			varInfo.vars.push_back(varInfo.var);
			return varInfo;
		} else if (UnaryOperator * specExpr = dyn_cast<UnaryOperator>(expr)) {
			string op = specExpr->getOpcodeStr(specExpr->getOpcode()).data();
			subExpr = specExpr->getSubExpr();
			VarInfo ret = getVar(subExpr);
			return VarInfo("(" + op + "(" + ret.var + "))", ret.fpVar, ret.vars);
		} else if (ParenExpr * specExpr = dyn_cast<ParenExpr>(expr)) {
			return getVar(specExpr->getSubExpr());
		} else if (ImplicitCastExpr * specExpr = dyn_cast<ImplicitCastExpr>(expr)) {
			return getVar(specExpr->getSubExpr());
		} else if (CStyleCastExpr *specExpr = dyn_cast<CStyleCastExpr>(expr)) {
			string type = specExpr->getType().getAsString().data();
			VarInfo ret = getVar(specExpr->getSubExpr());
			return VarInfo("((" + type + ")" + ret.var + ")", ret.fpVar, ret.vars); 
		} else if (ArraySubscriptExpr * specExpr = dyn_cast<ArraySubscriptExpr>(expr)) {
			VarInfo ret = getVar(specExpr->getBase());
			VarInfo retInd = getVar(specExpr->getIdx());
			string ind = retInd.var;
			string arr = ret.var + "[" + ind + "]";
			retInd.vars.push_back(arr);
			return VarInfo(arr, ret.fpVar, retInd.vars);
		} else if (MemberExpr * specExpr = dyn_cast<MemberExpr>(expr)) {
			string base = getVar(specExpr->getBase()).var;
			bool isMynumber = false;
			specExpr->getBase()->getType().dump();
			if (strcmp(specExpr->getBase()->getType().getAsString().data(), "mynumber") == 0) {
				isMynumber = true;
			}
			string ref = specExpr->getMemberNameInfo().getAsString().data();
			if (specExpr->isArrow()) {
				VarInfo ret(base + "->" + ref);
				if (isMynumber && ref.substr(0, 1) == "i") {
					ret.fpVar = base + "->d"; 
				}
				ret.vars.push_back(base + "->" + ref);
				return ret;
			} else {
				VarInfo ret(base + "." + ref);
				if (isMynumber && ref.substr(0, 1) == "i") {
					ret.fpVar = base + ".d"; 
				}
				ret.vars.push_back(base + "." + ref);
				return ret;
			}
		} else if (CallExpr *specExpr = dyn_cast<CallExpr>(expr)) {
			string func = specExpr->getCalleeDecl()->getAsFunction()->getNameAsString();
			func.append("(");
			int numArgs = specExpr->getNumArgs();
			VarInfo varInfo;
			for(int i = 0; i < numArgs; i++) {
				VarInfo arg = getVar(specExpr->getArg(i));
				func.append(arg.var);
				for(int i = 0; i < arg.vars.size(); i++) {
					varInfo.vars.push_back(arg.vars[i]);
				}
				if (i != numArgs - 1) {
					func.append(", ");
				}
			}
			func.append(")");
			callExprCount++;
			varInfo.var = func;
			return varInfo;
		} else if (DeclRefExpr * specExpr = dyn_cast<DeclRefExpr>(expr)) {
			string ret = specExpr->getNameInfo().getAsString().data();
			cout << "declref:" << ret << endl;
			VarInfo varInfo(ret);
			varInfo.vars.push_back(ret);
			return varInfo;
		} else {
			/*if (isa<UnaryExprOrTypeTraitExpr>(*expr)) {
			cout << rewriter.getRewrittenText(expr->getSourceRange()) << endl;
			}*/
			if (isa<ConditionalOperator>(*expr)) {
				biExprCount += countBinaryOp(expr);
			}
			string ret = rewriter.getRewrittenText(getSourceRange(expr));
			cout << "ret:" << ret << endl;
			//if (ret.empty()) {
				
				/*} else if (IntegerLiteral * specExpr = dyn_cast<IntegerLiteral>(expr)) {
				return VarInfo(specExpr->getValue().toString(10,true));
				} else if (FloatingLiteral * specExpr = dyn_cast<FloatingLiteral>(expr)) {
				hasDefine = true; // do not find a better way to deal with this case
				}*/
			//}
			//cout << "re" << rewriter.getRewrittenText(expr->getSourceRange()) << endl;
			VarInfo varInfo(ret);
			if (!isLiteral && !isMacro(expr)) varInfo.vars.push_back(ret);
			return varInfo;
		}
	}

	VarInfo threeAddrCode(BinaryOperator * biExpr) {
		Expr *lhs, *rhs;
		biExprCount++;

		VarInfo leftVar = getVar(biExpr->getLHS());
		VarInfo rightVar = getVar(biExpr->getRHS());

		string op = biExpr->getOpcodeStr().data();
		string type = biExpr->getType().getAsString();
		string statment;
		string varName("");
		bool reduceLeftVar = true;
		if (op == "=") {
			statment = leftVar.var + " = " + rightVar.var + ";";
			reduceLeftVar = false;
		} else if (isa<CompoundAssignOperator>(*biExpr)) {
			statment = leftVar.var + op + rightVar.var + ";";
		} else {
			varName = tempVar + toString(varCount);
			statment = varName + " = " + leftVar.var + " " + op + " " + rightVar.var + ";";
			varCount++;
		}

		VarInfo varInfo;

		// insert fpdebug statements.
		if (type == "double" || type == "float" || type == "long double") {
			string tag = toString(tagCount);
			string temp("");
			if (varName.empty()) {
				varName = leftVar.var;
			} else {
				temp.append(type + " " + varName + ";");
			}
			
			unordered_set<string> inputs;
			string tag_ = tag + "_";
			if (reduceLeftVar) {
				for(int i = 0; i < leftVar.vars.size(); i++) {
					if (inputs.find(leftVar.vars[i]) != inputs.end()) continue;
					temp.append(FDReduceStr(leftVar.vars[i], tag_, type.substr(0, 1)))
						.append(FDErrorStr(leftVar.vars[i], tag_, type.substr(0, 1)));
					inputs.insert(leftVar.vars[i]);
				}
			}
			for(int i = 0; i < rightVar.vars.size(); i++) {
				if (inputs.find(rightVar.vars[i]) != inputs.end()) continue;
				temp.append(FDReduceStr(rightVar.vars[i], tag_, type.substr(0, 1)))
					.append(FDErrorStr(rightVar.vars[i], tag_, type.substr(0, 1)));
				inputs.insert(rightVar.vars[i]);
			}
			//varInfo.vars.push_back(varName);

			temp.append("\n").append(statment).
				append(FDResumeStr(varName, tag, type.substr(0, 1))).
				append(FDErrorStr(varName, tag, type.substr(0, 1)));
			statment = temp;
			tagCount++;
			/*} else if (!leftVar.fpVar.empty() && varName.empty()) {
			string temp("");
			string tag = toString(tagCount);
			temp.append(FDReduceStr(leftVar.fpVar, tag, "d")).
			append(statment).
			append(FDResumeStr(leftVar.fpVar, tag, "d"));
			statment = temp;
			tagCount++;*/
		} else if (!varName.empty()) {
			statment = type + " " + varName + " = " + leftVar.var + " " + op + " " + rightVar.var + ";";
		}

		stats.push_back(statment);
		varInfo.var = varName;
		
		return varInfo;
	}

	string process(BinaryOperator * biExpr) {
		string texts("");
		cout << "iii " << biExprCount << endl;
		if (biExprCount == 0) {
			lastNewVar = threeAddrCode(biExpr);
			biExpr->dump();
			vector<string>::iterator it;
			for(it = stats.begin(); it != stats.end(); it++) {
				texts.append((*it)).append("\n");			
			}
			rewriter.ReplaceText(getSourceRange(biExpr), texts);
			isChanged = true;
			stats.clear();
		}
		biExprCount--;
		return texts;
	}

public:
	explicit TACTransformVisitor(CompilerInstance *CI) 
		:astContext(&(CI->getASTContext())) // initialize private members
	{
		ignore = false;
		varCount = 0;
		biExprCount = 0;
		callExprCount = 0;
		ifstream in(logfile);
		in >> tagCount;
		in.close();
	}

	virtual bool VisitBinaryOperator(BinaryOperator * biOp) {
		if (ignore)
			return true;
		process(biOp);
		return true;
	}

	virtual bool TraverseForStmt(ForStmt * stmt) {
		if (!WalkUpFromForStmt(stmt))
			return false;
		bool preIgnore = ignore;
		for (Stmt::child_range range = stmt->children(); range; ++range) {
			if (*range == stmt->getBody()) {
				if (!preIgnore) {
					ignore = false;
				}
			}
			else 
				ignore = true;
			TraverseStmt(*range);
		}
		ignore = preIgnore;
		return true;
	}

	virtual bool TraverseCaseStmt(CaseStmt * stmt) {
		if (!WalkUpFromCaseStmt(stmt))
			return false;
		bool preIgnore = ignore;
		for (Stmt::child_range range = stmt->children(); range; ++range) {
			if (*range == stmt->getLHS())
				ignore = true;
			else if (!preIgnore) {
				ignore = false;
			}
			TraverseStmt(*range);
		}
		ignore = preIgnore;
		return true;
	}

	virtual bool TraverseCallExpr(CallExpr * stmt) {
		if (!WalkUpFromCallExpr(stmt))
			return false;
		bool preIgnore = ignore;
		for (Stmt::child_range range = stmt->children(); range; ++range) {
			if (*range == stmt->getCallee()) {
				if (!preIgnore) {
					ignore = false;
				}
			}
			else 
				ignore = true;
			if (callExprCount != 0) // visit before
				ignore = false;
			TraverseStmt(*range);
		}
		ignore = preIgnore;
		if (callExprCount > 0) callExprCount--;
		return true;
	}
};



class TACTransformASTConsumer : public ASTConsumer {
private:
	TACTransformVisitor *visitor; // doesn't have to be private

public:
	// override the constructor in order to pass CI
	explicit TACTransformASTConsumer(CompilerInstance *CI)
		: visitor(new TACTransformVisitor(CI)) // initialize the visitor
	{ }

	// override this to call our TACTransformVisitor on the entire source file
	virtual void HandleTranslationUnit(ASTContext &Context) {
		/* we can use ASTContext to get the TranslationUnitDecl, which is
		a single Decl that collectively represents the entire source file */
		visitor->TraverseDecl(Context.getTranslationUnitDecl());
	}
};



class TACTransformFrontendAction : public ASTFrontendAction {
public:
	virtual std::unique_ptr<ASTConsumer> CreateASTConsumer(CompilerInstance &CI, StringRef file) {
		rewriter.setSourceMgr(CI.getSourceManager(), CI.getLangOpts());
		return std::unique_ptr<ASTConsumer>(new TACTransformASTConsumer(&CI)); // pass CI pointer to ASTConsumer
	}
};

#endif