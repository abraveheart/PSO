#ifndef CONSTANTS_H
#define CONSTANTS_H

#include "Headers.h"

Rewriter rewriter;
static cl::OptionCategory MyToolCategory("");

//log
const string logfile("tac.log");
int tagCount;
bool isChanged = false;
const string errorLog("err.log");

//fpdebug
const string printError = "computeErr";
const string printReduce = "reducePrec";
const string printResume = "resumePrec";

//variable name
const string tempVar = "temp_var_for_tac_";
const string extractVar = "temp_var_for_ext_";
const string coopVar = "temp_var_for_coop_";

//file suffix
const string ip = "_p.c";
const string uco = "_u.c";
const string es = "_e.c";
const string tac = "_tac.c";

#endif