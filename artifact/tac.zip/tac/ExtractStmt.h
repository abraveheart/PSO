#ifndef EXTRACTSTMT_H
#define EXTRACTSTMT_H

#include "Headers.h"
#include "Constants.h"
#include "Utils.h"

class CondInfo {
public:
	CondInfo() {
		decl = "";
		stmt = "";
		varName = "";
	}
	string decl;
	string stmt;
	string varName;
};

class ExtractStmtVisitor : public RecursiveASTVisitor<ExtractStmtVisitor> {
private:
	ASTContext *astContext; // used for getting additional AST info

	SourceLocation beginLoc;

	int varCount;

	bool isForInit;

	CondInfo condInfoProducer(Expr * cond) {
		CondInfo info;
		if (cond != NULL) {
			cond->dump();
			string type = cond->getType().getAsString().data();
			string varName = extractVar + toString(varCount);
			varCount++;
			info.decl.append(type)
				.append(" ")
				.append(varName)
				.append(";\n");
			info.stmt.append(varName)
				.append(" = ")
				.append(rewriter.getRewrittenText(getSourceRange(cond)))
				.append(";\n");
			info.varName = varName;
		}
		return info;
	}

public:
	explicit ExtractStmtVisitor(CompilerInstance *CI) 
		:astContext(&(CI->getASTContext())) // initialize private members
	{
		varCount = 0;
		isForInit = false;
	}

	virtual bool VisitIfStmt(IfStmt * stmt) {
		if (stmt->getCond() == NULL) return true;
		if (!isSameFile(stmt->getCond()->getLocStart()) 
			|| !(isSameFile(stmt->getLocStart()))) 
			return true;
		SourceLocation loc = getPureLocFirst(stmt->getLocStart());
		if (SLcmp(loc, getPureLocFirst(stmt->getCond()->getLocStart())) != SL_LESS)
			return true;
		CondInfo info = condInfoProducer(stmt->getCond());
		rewriter.ReplaceText(getSourceRange(stmt->getCond()), info.varName);
		rewriter.InsertTextBefore(getPureLocFirst(stmt->getLocStart()), info.decl + info.stmt);
		isChanged = true;
		return true;
	}

	virtual bool VisitSwitchStmt(SwitchStmt * stmt) {
		if (stmt->getCond() == NULL) return true;
		if (!isSameFile(stmt->getCond()->getLocStart()) 
			|| !(isSameFile(stmt->getLocStart()))) 
			return true;
		SourceLocation loc = getPureLocFirst(stmt->getLocStart());
		if (SLcmp(loc, getPureLocFirst(stmt->getCond()->getLocStart())) != SL_LESS)
			return true;
		CondInfo info = condInfoProducer(stmt->getCond());
		rewriter.ReplaceText(getSourceRange(stmt->getCond()), info.varName);
		rewriter.InsertTextBefore(getPureLocFirst(stmt->getLocStart()), info.decl + info.stmt);
		isChanged = true;
		return true;
	}

	virtual bool VisitWhileStmt(WhileStmt * stmt) {
		if (stmt->getCond() == NULL) return true;
		if (!isSameFile(stmt->getCond()->getLocStart()) 
			|| !(isSameFile(stmt->getLocStart()))
			|| !(isSameFile(stmt->getBody()->getLocStart())))
			return true;
		SourceLocation loc1 = getPureLocFirst(stmt->getLocStart());
		SourceLocation loc2 = getPureLocSecond(stmt->getBody()->getLocEnd());
		SourceLocation loc3 = getPureLocFirst(stmt->getCond()->getLocStart());
		if (!(SLcmp(loc1, loc3) == SL_LESS 
			&& SLcmp(loc3, loc2) == SL_LESS))
			return true;
		CondInfo info = condInfoProducer(stmt->getCond());
		rewriter.ReplaceText(getSourceRange(stmt->getCond()), info.varName);
		rewriter.InsertTextBefore(loc1, info.decl + info.stmt);
		rewriter.InsertTextBefore(loc2, info.stmt);
		isChanged = true;
		return true;
	}

	virtual bool VisitDoStmt(DoStmt * stmt) {
		if (stmt->getCond() == NULL) return true;
		if (!isSameFile(stmt->getCond()->getLocStart()) 
			|| !(isSameFile(stmt->getLocStart()))
			|| !(isSameFile(stmt->getBody()->getLocStart()))) 
			return true;
		SourceLocation loc1 = getPureLocSecond(stmt->getBody()->getLocEnd());
		SourceLocation loc2 = getPureLocFirst(stmt->getLocStart());
		if (!(SLcmp(loc2, loc1) == SL_LESS 
			&& SLcmp(loc1, getPureLocFirst(stmt->getCond()->getLocStart())) == SL_LESS))
			return true;
		CondInfo info = condInfoProducer(stmt->getCond());
		rewriter.ReplaceText(getSourceRange(stmt->getCond()), info.varName);
		rewriter.InsertTextBefore(loc1, info.stmt);
		rewriter.InsertTextBefore(loc2, info.decl);
		isChanged = true;
		return true;
	}

	virtual bool VisitReturnStmt(ReturnStmt * stmt) {
		if (stmt->getRetValue() == NULL) return true;
		if (!isSameFile(stmt->getRetValue()->getLocStart()) 
			|| !(isSameFile(stmt->getLocStart()))) 
			return true;
		SourceLocation loc = getPureLocFirst(stmt->getLocStart());
		if (SLcmp(loc, getPureLocFirst(stmt->getRetValue()->getLocStart())) != SL_LESS)
			return true;
		CondInfo info = condInfoProducer(stmt->getRetValue());
		rewriter.ReplaceText(getSourceRange(stmt->getRetValue()), info.varName);
		rewriter.InsertTextBefore(loc, info.decl + info.stmt);
		isChanged = true;
		return true;
	}

	virtual bool TraverseForStmt(ForStmt * stmt) {
		if (!WalkUpFromForStmt(stmt))
			return false;
		for (Stmt::child_range range = stmt->children(); range; ++range) {
			if (stmt->getInit() != NULL && *range == stmt->getInit())
				isForInit = true;
			else 
				isForInit = false;
			TraverseStmt(*range);
		}
		isForInit = false;
		return true;
	}

	/*virtual bool VisitVarDecl(VarDecl * decl) {
		if (decl->getInit() == NULL || isForInit)
			return true;
		decl->dump();
		string name = decl->getNameAsString();
		string type = decl->getType().getAsString().data();
		string texts("");
		texts.append(type)
			.append(" ")
			.append(name)
			.append(";\n")
			.append(name)
			.append(" = ")
			.append(rewriter.getRewrittenText(getSourceRange(decl->getInit())))
			.append(";\n");
		rewriter.ReplaceText(getSourceRange(decl), texts);
		isChanged = true;
		return true;
	}*/

};

class ExtractStmtASTConsumer : public ASTConsumer {
private:
	ExtractStmtVisitor *visitor; // doesn't have to be private

public:
	// override the constructor in order to pass CI
	explicit ExtractStmtASTConsumer(CompilerInstance *CI)
		: visitor(new ExtractStmtVisitor(CI)) // initialize the visitor
	{ }

	// override this to call our ExtractStmtVisitor on the entire source file
	virtual void HandleTranslationUnit(ASTContext &Context) {
		/* we can use ASTContext to get the TranslationUnitDecl, which is
		a single Decl that collectively represents the entire source file */
		visitor->TraverseDecl(Context.getTranslationUnitDecl());
	}
};



class ExtractStmtFrontendAction : public ASTFrontendAction {
public:
	virtual std::unique_ptr<ASTConsumer> CreateASTConsumer(CompilerInstance &CI, StringRef file) {
		rewriter.setSourceMgr(CI.getSourceManager(), CI.getLangOpts());
		return std::unique_ptr<ASTConsumer>(new ExtractStmtASTConsumer(&CI)); // pass CI pointer to ASTConsumer
	}
};

#endif