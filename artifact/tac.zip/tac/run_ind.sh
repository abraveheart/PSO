#!/bin/sh

suf1="_p.c"
suf2="_u.c"
suf3="_e.c"
suf4="_tac.c"
# modify gccinclulde to point to your gcc include directory
# The label for computation increases from the number in tac.log. 
exarg=-I/usr/lib/gcc/x86_64-linux-gnu/4.8/include/

rm $1_*
if [ -e $1${suf1}]
then
	rm $1${suf1}
fi
./insp $1 -extra-arg=$exarg --
if [ ! -e $1${suf1} ]
then
	cp $1 $1${suf1}
fi
./unfold $1${suf1} -extra-arg=$exarg --
if [ ! -e $1${suf1}${suf2} ]
then
        cp $1${suf1} $1${suf1}${suf2}
fi
./ext $1${suf1}${suf2} -extra-arg=$exarg --
if [ ! -e $1${suf1}${suf2}${suf3} ]
then
        cp $1${suf1}${suf2} $1${suf1}${suf2}${suf3}
fi
./tac $1${suf1}${suf2}${suf3} -extra-arg=$exarg --
if [ ! -e $1${suf1}${suf2}${suf3}${suf4} ]
then
        cp $1${suf1}${suf2}${suf3} $1${suf1}${suf2}${suf3}${suf4}
fi

mv $1${suf1}${suf2}${suf3}${suf4} $1${suf4}
rm $1${suf1}${suf2}${suf3}
rm $1${suf1}${suf2}
rm $1${suf1}
