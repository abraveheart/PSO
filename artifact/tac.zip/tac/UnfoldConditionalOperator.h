#ifndef UNFOLDCONDITIONALOPERATOR_H
#define UNFOLDCONDITIONALOPERATOR_H

#include "Headers.h"
#include "Constants.h"
#include "Utils.h"

class UnfoldCondOpVisitor : public RecursiveASTVisitor<UnfoldCondOpVisitor> {
private:
	ASTContext *astContext; // used for getting additional AST info

	SourceLocation beginLoc;

	Stmt * containerStmt;

	int biExprCount;

	bool hasCondOp;

	int varCount;

	int traverseBinaryOp(Stmt *stmt) {
		if (stmt == NULL) return 0;
		Stmt::child_iterator it = stmt->child_begin();
		int num = 0;
		for(; it != stmt->child_end(); it++) {
			num += traverseBinaryOp(*it);
		}
		if (isa<BinaryOperator>(*stmt)) {
			num++;
		} else if (isa<ConditionalOperator>(*stmt)) {
			hasCondOp = true;
		}
		return num;
	}

	bool traverseReturnStmt(Stmt *stmt) {
		if (stmt == NULL) return 0;
		if (isa<ConditionalOperator>(*stmt)) {
			return true;
		}
		Stmt::child_iterator it = stmt->child_begin();
		for(; it != stmt->child_end(); it++) {
			if (traverseReturnStmt(*it)) return true;
		}
		return false;
	}


public:
	explicit UnfoldCondOpVisitor(CompilerInstance *CI) 
		:astContext(&(CI->getASTContext())) // initialize private members
	{
		
		biExprCount = 0;
		hasCondOp = false;
		varCount = 0;
	}

	virtual bool VisitBinaryOperator(BinaryOperator * stmt) {
		if (biExprCount != 0) {
			biExprCount--;
			return true;
		}
		hasCondOp = false;
		biExprCount += traverseBinaryOp(stmt) - 1;
		if (hasCondOp) {
			containerStmt = stmt;
		}
		return true;
	}

	virtual bool VisitReturnStmt(ReturnStmt * stmt) {
		if (traverseReturnStmt(stmt)) {
			containerStmt = stmt;
		}
		return true;
	}

	virtual bool VisitConditionalOperator(ConditionalOperator * stmt) {
		if (!isSameFile(stmt->getLocStart()) || !isSameFile(containerStmt->getLocStart())) return true;
		string cond = rewriter.getRewrittenText(getSourceRange(stmt->getCond()));
		string lhs = rewriter.getRewrittenText(getSourceRange(stmt->getLHS()));
		string rhs = rewriter.getRewrittenText(getSourceRange(stmt->getRHS()));
		if (cond == lhs && lhs == rhs) return true;
		stmt->dump();
		string varName = coopVar + toString(varCount);
		string type = stmt->getType().getAsString().data();
		varCount++;
		string texts("");
		texts.append(type)
			.append(" ")
			.append(varName)
			.append(";\nif (")
			.append(cond)
			.append(") {\n")
			.append(varName)
			.append(" = ")
			.append(lhs)
			.append(";\n} else {")
			.append(varName)
			.append(" = ")
			.append(rhs)
			.append(";\n}\n");
		rewriter.ReplaceText(getSourceRange(stmt), varName);
		cout << texts << endl;
		rewriter.InsertTextBefore(getPureLocFirst(containerStmt->getLocStart()), texts);
		isChanged = true;
		return true;
	}

};

class UnfoldCondOpASTConsumer : public ASTConsumer {
private:
	UnfoldCondOpVisitor *visitor; // doesn't have to be private

public:
	// override the constructor in order to pass CI
	explicit UnfoldCondOpASTConsumer(CompilerInstance *CI)
		: visitor(new UnfoldCondOpVisitor(CI)) // initialize the visitor
	{ }

	// override this to call our UnfoldCondOpVisitor on the entire source file
	virtual void HandleTranslationUnit(ASTContext &Context) {
		/* we can use ASTContext to get the TranslationUnitDecl, which is
		a single Decl that collectively represents the entire source file */
		visitor->TraverseDecl(Context.getTranslationUnitDecl());
	}
};



class UnfoldCondOpFrontendAction : public ASTFrontendAction {
public:
	virtual std::unique_ptr<ASTConsumer> CreateASTConsumer(CompilerInstance &CI, StringRef file) {
		rewriter.setSourceMgr(CI.getSourceManager(), CI.getLangOpts());
		return std::unique_ptr<ASTConsumer>(new UnfoldCondOpASTConsumer(&CI)); // pass CI pointer to ASTConsumer
	}
};

#endif