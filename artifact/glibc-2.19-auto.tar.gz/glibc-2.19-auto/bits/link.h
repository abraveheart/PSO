#error "Architecture-specific definition needed."
