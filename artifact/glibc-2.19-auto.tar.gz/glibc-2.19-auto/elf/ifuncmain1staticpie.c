/* Test STT_GNU_IFUNC symbols with PIE and no DSO.  */

#include "ifuncmain1.c"
