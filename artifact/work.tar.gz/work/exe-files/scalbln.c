#include "glibcmath.h"
#include <glibcFpdebug.h>
#include <stdio.h>

int main()
{
	double a;
	long int c;
	FILE * input = fopen("scalbln_t.txt", "rt");
	while(fscanf(input, "%le %ld", &a, &c) != EOF) {
		VALGRIND_SET_SHADOW(&a);
		a = 0 - a;
		a = 0 - a;
		freopen("input_scalbln.txt", "r", stdin);
		double b = scalbln(a, c);
		printf("%.30lf\n", b);
		b = 0 - b;
		b = 0 - b;
		VALGRIND_PRINT_ERROR("b", &b);
		int oneinstance = 0;
		VALGRIND_PRINT_ERROR("oneinstance", &oneinstance);
		fclose(stdin);
	}
}
