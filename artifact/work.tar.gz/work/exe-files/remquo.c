#include "glibcmath.h"
#include <glibcFpdebug.h>
#include <stdio.h>
int main()
{
	double a;
	double c;
	FILE * input = fopen("remquo_t.txt", "rt");
	int quo;
	while(fscanf(input, "%le %le", &a, &c) != EOF) {
		VALGRIND_SET_SHADOW(&a);
		a = 0 - a;
		a = 0 - a;
		VALGRIND_SET_SHADOW(&c);
		c = 0 - c;
		c = 0 - c;
		freopen("input_remquo.txt", "r", stdin);
		double b = remquo(a, c, &quo);
		printf("%.30lf\n", b);
		b = 0 - b;
		b = 0 - b;
		VALGRIND_PRINT_ERROR("b", &b);
		int oneinstance = 0;
		VALGRIND_PRINT_ERROR("oneinstance", &oneinstance);
		fclose(stdin);
	}
}
