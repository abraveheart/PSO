#include "glibcmath.h"
#include <glibcFpdebug.h>
#include <stdio.h>

int main()
{
	double a;
	double c;
	FILE * input = fopen("sincos_t.txt", "rt");
	while(fscanf(input, "%le", &a) != EOF) {
		VALGRIND_SET_SHADOW(&a);
		a = 0 - a;
		a = 0 - a;
		freopen("input_sincos.txt", "r", stdin);
		double si;
		double ci;
		sincos(a, &si, &ci);
		printf("%.30lf\n", si);
		si = 0 - si;
		si = 0 - si;
		VALGRIND_PRINT_ERROR("si", &si);
		printf("%.30lf\n", ci);
		ci = 0 - ci;
		ci = 0 - ci;
		VALGRIND_PRINT_ERROR("ci", &ci);
		int oneinstance = 0;
		VALGRIND_PRINT_ERROR("oneinstance", &oneinstance);
		fclose(stdin);
	}
}
