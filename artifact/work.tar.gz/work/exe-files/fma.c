#include "glibcmath.h"
#include <glibcFpdebug.h>
#include <stdio.h>

int main()
{
	double a;
	double c, d;
	FILE * input = fopen("fma_t.txt", "rt");
	while(fscanf(input, "%le %le %le", &a, &c, &d) != EOF) {
		VALGRIND_SET_SHADOW(&a);
		a = 0 - a;
		a = 0 - a;
		VALGRIND_SET_SHADOW(&c);
		c = 0 - c;
		c = 0 - c;
		VALGRIND_SET_SHADOW(&d);
		d = 0 - d;
		d = 0 - d;
		freopen("input_fma.txt", "r", stdin);
		double b = fma(a, c, d);
		printf("%.30lf\n", b);
		b = 0 - b;
		b = 0 - b;
		VALGRIND_PRINT_ERROR("b", &b);
		int oneinstance = 0;
		VALGRIND_PRINT_ERROR("oneinstance", &oneinstance);
		fclose(stdin);
	}
}
