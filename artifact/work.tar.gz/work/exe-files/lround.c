#include "glibcmath.h"
#include <glibcFpdebug.h>
#include <stdio.h>

int main()
{
	double a;
	double c;
	FILE * input = fopen("lround_t.txt", "rt");
	while(fscanf(input, "%le", &a) != EOF) {
		VALGRIND_SET_SHADOW(&a);
		a = 0 - a;
		a = 0 - a;
		freopen("input_lround.txt", "r", stdin);
		long int b = lround(a);
		printf("%ld\n", b);
		VALGRIND_PRINT_ERROR("b", &b);
		int oneinstance = 0;
		VALGRIND_PRINT_ERROR("oneinstance", &oneinstance);
		fclose(stdin);
	}
}
