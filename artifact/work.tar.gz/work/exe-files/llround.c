#include "glibcmath.h"
#include <glibcFpdebug.h>
#include <stdio.h>

int main()
{
	double a;
	double c;
	FILE * input = fopen("llround_t.txt", "rt");
	while(fscanf(input, "%le", &a) != EOF) {
		VALGRIND_SET_SHADOW(&a);
		a = 0 - a;
		a = 0 - a;
		freopen("input_llround.txt", "r", stdin);
		long long int b = llround(a);
		printf("%lld\n", b);
		VALGRIND_PRINT_ERROR("b", &b);
		int oneinstance = 0;
		VALGRIND_PRINT_ERROR("oneinstance", &oneinstance);
		fclose(stdin);
	}
}
