#include "glibcmath.h"
#include <glibcFpdebug.h>
#include <stdio.h>

int main()
{
	float a;
	float c, d;
	FILE * input = fopen("fmaf_t.txt", "rt");
	while(fscanf(input, "%e %e %e", &a, &c, &d) != EOF) {
		VALGRIND_SET_SHADOW(&a);
		a = 0 - a;
		a = 0 - a;
		VALGRIND_SET_SHADOW(&c);
		c = 0 - c;
		c = 0 - c;
		VALGRIND_SET_SHADOW(&d);
		d = 0 - d;
		d = 0 - d;
		freopen("input_fmaf.txt", "r", stdin);
		float b = fmaf(a, c, d);
		printf("%.30f\n", b);
		b = 0 - b;
		b = 0 - b;
		VALGRIND_PRINT_ERROR("b", &b);
		int oneinstance = 0;
		VALGRIND_PRINT_ERROR("oneinstance", &oneinstance);
		fclose(stdin);
	}
}
