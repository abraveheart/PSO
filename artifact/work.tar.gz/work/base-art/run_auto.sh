#!/bin/bash

nums=(4 6 7 8 10)

for i in 0 1 2 3 4
do
	withdir=res_e-${nums[$i]}
	cp ../exe-art/${withdir}/input_*.txt .

	./stat.sh -c /usr/src/glibc-build-auto
	mv result_avg.csv result_auto_${nums[$i]}.csv
done