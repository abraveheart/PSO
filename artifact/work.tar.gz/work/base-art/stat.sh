#!/bin/bash

USAGE="Usage: ./stat.sh [-m dir_of_mpfr] [-r name_of_mpfr_library] 
[-g dir_of_gmp] [-p name_of_gmp_library] 
[-c dir_of_glibc] [-b name_of_glibc_library]"

MPFRDIR="/usr/src/mpfr-build"
MPFRLIB="mpfr1"
GMPDIR="/usr/src/gmp-build2"
GMPLIB="gmp1"
GLIBCDIR="/usr/src/glibc-build-auto"
GLIBCLIB="m1"

while getopts m:r:g:p:c:b:e:h OPTION ; do
    case "$OPTION" in
        m) MPFRDIR="$OPTARG" ;;
        r) MPFRLIB="$OPTARG" ;;
        g) GMPDIR="$OPTARG" ;;
        p) GMPLIB="$OPTARG" ;;
        c) GLIBCDIR="$OPTARG" ;;
        b) GLIBCLIB="$OPTARG" ;;
        h) echo "$USAGE" ;
                exit 1;;
        \?) echo "$USAGE" ;
                exit 1;;
        esac
done

cp ../exe-small/*.c .
cp ../exe-small/*.h .
cp ../exe-input/*_t.txt .
cp ../std/*_out.txt .
cp ../original/*_low.txt .

g++ Extract.cpp -o Extract
g++ Checker.cpp -L$MPFRDIR/lib -l$MPFRLIB -L$GMPDIR/lib -l$GMPLIB -o Checker
files=`ls *.c`
echo "function,M>=L,M>L,M<L,M>=H,M>H,M<H,H>=L,H>L,H<L,mavg,lavg,havg" > result_avg.csv

for filename in $files
do
    execfile=${filename%\.c}
    echo -n ${execfile}, >> result_avg.csv
    echo ${execfile}
    echo "executing..."
    gcc $filename -g -L$GLIBCDIR/lib -l$GLIBCLIB -o $execfile

    valgrind --tool=fpdebug ./$execfile > ${execfile}.txt 2>&1
    ./Extract $execfile tmp

    inputfile=input_${execfile}.txt
    inputfile_back=${inputfile}.back
    mv ${inputfile} ${inputfile_back}
    
    #get high precision result
    echo 1000 -1 > temp.txt
    ./input < temp.txt > $inputfile
    valgrind --tool=fpdebug ./$execfile > ${execfile}.txt 2>&1
    ./Extract $execfile high
 
    echo "checking..."
    ./Checker $execfile
    rm *shadow*
    rm *vcg*
    rm *mean*
    
    rm temp.txt
    rm ${execfile}.txt
    rm ${execfile}high.txt
    rm ${execfile}_out.txt
    rm ${execfile}_low.txt
    rm ${execfile}tmp.txt
    mv ${inputfile_back} ${inputfile}
    rm $execfile
done
