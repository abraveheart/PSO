#!/bin/sh

files=`ls *.c`

for file in $files
do
	execfile=${file%\.c}
	./input < input_right > input_${execfile}.txt
done

./stat.sh -c /usr/src/glibc-build-auto
mv result_avg.csv result_fixlast.csv