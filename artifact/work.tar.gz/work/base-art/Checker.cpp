#include <iostream>
#include <fstream>
#include <gmp.h>
#include <mpfr.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
using namespace std;

int main(int argc, char const *argv[])
{
	char fixedfile[20], stdfile[20], lowfile[20], highfile[20];
	strcpy(fixedfile, argv[1]);
	strcat(fixedfile, "tmp.txt");
	strcpy(stdfile, argv[1]);
	strcat(stdfile, "_out.txt");
	strcpy(lowfile, argv[1]);
	strcat(lowfile, "_low.txt");
	strcpy(highfile, argv[1]);
	strcat(highfile, "high.txt");
	string fans, sans, lans, hans;
	int total = 0, mnum_l = 0, lnum = 0, mnum_h = 0, hnum = 0, hnum_l = 0, lnum_h = 0;
	ifstream finput(fixedfile);
	ifstream sinput(stdfile);
	ifstream linput(lowfile);
	ifstream hinput(highfile);

	FILE * result = fopen("result_avg.csv", "a+");                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
	mpfr_t favg, lavg, havg;
	mpfr_init2(favg, 200);
	mpfr_set_d(favg, 0, MPFR_RNDN);
	mpfr_init2(lavg, 200);
	mpfr_set_d(lavg, 0, MPFR_RNDN);
	mpfr_init2(havg, 200);
	mpfr_set_d(havg, 0, MPFR_RNDN);
	mpfr_t t1,t2,t3;
	mpfr_init2(t1, 200);
	mpfr_init2(t2, 200);
	mpfr_init2(t3, 200);
	while(finput >> fans) {
		if (!(sinput >> sans)) {
			cout << "file length not match " << total << " s" << endl;
			break;
		}
		sinput >> sans;
        if (strcmp(argv[1], "pow") == 0 || strcmp(argv[1], "atan2") == 0) {
            sinput >> sans;
        }
		if (!(linput >> lans)) {
			cout << "fivi e length not match " << total << " l" << endl;
			break;
		}
		if (!(hinput >> hans)) {
			cout << "file length not match " << total << " h" << endl;
			break;
		}
		total += 1.0;
		mpfr_t f, s, l, h;

		char **endptr = NULL;
		mpfr_init2(f, 200);
		mpfr_strtofr(f, fans.c_str(), endptr, 10, MPFR_RNDN);
		mpfr_init2(s, 200);
		mpfr_strtofr(s, sans.c_str(), endptr, 10, MPFR_RNDN);
		mpfr_init2(l, 200);
		mpfr_strtofr(l, lans.c_str(), endptr, 10, MPFR_RNDN);
		mpfr_init2(h, 200);
		mpfr_strtofr(h, hans.c_str(), endptr, 10, MPFR_RNDN);
		mpfr_t fe, le, he;
		mpfr_init2(fe, 200);
		mpfr_init2(le, 200);
		mpfr_init2(he, 200);
		mpfr_sub(fe, f, s, MPFR_RNDN);
		mpfr_sub(le, l, s, MPFR_RNDN);
		mpfr_sub(he, h, s, MPFR_RNDN);
		if (mpfr_cmp_si(s, 0) == 0) { // if shadow value is equal to zero, set relative error to 1 if original value is not zero
			if (mpfr_cmp_si(fe, 0) == 0) {
				mpfr_set_si(f, 0, MPFR_RNDN);
			} else {
				mpfr_set_si(f, 1, MPFR_RNDN);
			}
			if (mpfr_cmp_si(le, 0) == 0) {
				mpfr_set_si(l, 0, MPFR_RNDN);
			} else {
				mpfr_set_si(l, 1, MPFR_RNDN);
			}
			if (mpfr_cmp_si(he, 0) == 0) {
				mpfr_set_si(h, 0, MPFR_RNDN);
			} else {
				mpfr_set_si(h, 1, MPFR_RNDN);
			}
		} else {
			mpfr_div(f, fe, s, MPFR_RNDN);
			mpfr_div(l, le, s, MPFR_RNDN);
			mpfr_div(h, he, s, MPFR_RNDN);
		}
		mpfr_abs(fe, f, MPFR_RNDN);
		mpfr_abs(le, l, MPFR_RNDN);
		mpfr_abs(he, h, MPFR_RNDN);
		int cmp = mpfr_cmp(fe, le);
		if (cmp > 0) lnum++;
		else if (cmp < 0) mnum_l++;
		int cmp2 = mpfr_cmp(fe, he);
		if (cmp2 > 0) hnum++;
		else if (cmp2 < 0) mnum_h++;
		int cmp3 = mpfr_cmp(he, le);
		if (cmp3 > 0) lnum_h++;
		else if (cmp3 < 0) hnum_l++;
		mpfr_add(t1, favg, fe, MPFR_RNDN);
		mpfr_add(t2, lavg, le, MPFR_RNDN);
		mpfr_add(t3, havg, he, MPFR_RNDN);
		mpfr_set(favg, t1, MPFR_RNDN);
		mpfr_set(lavg, t2, MPFR_RNDN);
		mpfr_set(havg, t3, MPFR_RNDN);
	}
	mpfr_div_si(t1, favg, total, MPFR_RNDN);
	mpfr_div_si(t2, lavg, total, MPFR_RNDN);
	mpfr_div_si(t3, havg, total, MPFR_RNDN);

	double mp_l = (double) mnum_l / (double) total;
	double lp = (double)lnum / (double)total;
	double mp_h = (double)mnum_h / (double)total;
	double hp = (double)hnum / (double)total;
	double hp_l = (double)hnum_l / (double)total;
	double lp_h = (double)lnum_h / (double)total;

	fprintf(result, "%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,", 
		1.0 - lp, mp_l, lp, 1.0 - hp, mp_h, hp, 1.0 - lp_h, hp_l, lp_h);
	mpfr_out_str(result, 10, 20, t1, MPFR_RNDN);
	fprintf(result, ",");
	mpfr_out_str(result, 10, 20, t2, MPFR_RNDN);
	fprintf(result, ",");
	mpfr_out_str(result, 10, 20, t3, MPFR_RNDN);
	fprintf(result, "\n");
	finput.close();
	sinput.close();
	linput.close();

	fclose(result);
	return 0;
}
