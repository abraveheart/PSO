#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <vector>
using namespace std;

string target("SHADOW");
string names[10] = {"b", "copyvar_pos_tag8646", "copyvar_neg_tag8646"};
string noshadow("b!");

void change(string & s) {
	if (s[0] != '-') {
		if (s.size() == 1) s = "0" + s;
		s = "+" + s;
	} else {
		string res = s.substr(1);
		if (res.size() == 1) s = "-0" + res;
	}
}

void print(ofstream & out, string s) {
	out << s << endl;
}

void positive(ifstream & in, ofstream & out) {
	string line;
	in >> line;
	string frac;
	in >> frac;
	in >> line; // *
	in >> line;
	string expp = line.substr(3, line.size() - 4);
	change(expp);
	print(out, frac + "e" + expp);
}

int main(int argc, char const *argv[]) {
	char infile[100];
	strcpy(infile, argv[1]);
	strcat(infile, ".txt");
	ifstream in(infile);
	char outfile[100];
	strcpy(outfile, argv[1]);
	strcat(outfile, argv[2]);
	strcat(outfile, ".txt");
	ofstream out(outfile);

	string line;
	string last;
	bool output = false;
	int cnt = 1;
	while(in >> line) {
		if (line == target) {
			in >> line;
			if (last == names[0]) {
				if (!output) {
					in >> line;
					print(out, line);
				}
				output = false;
				cnt++;
			} else if (last == names[1]) {
				in >> line;
				print(out, line);
				output = true;
			} else if (last == names[2]) {
				in >> line;
				if (line[0] == '-') line = line.substr(1);
				else {
					double x = atof(line.c_str());
					if (x != 0) line = "-" + line;
				}
				print(out, line);
				output = true;
			}
		} else if (line == noshadow) {
			if (!output) {
				print(out, "noshadow");
			}
			output = false;
			cnt++;
		}
		last = line;
	}
	in.close();
	out.close();
	return 0;
}