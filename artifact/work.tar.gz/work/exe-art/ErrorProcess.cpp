#include <fstream>
#include <iostream>
#include <set>
#include <dirent.h>
#include <string.h>
#include <string>
#include <vector>

using namespace std;

set<int> r;
int main(int argc, char const *argv[])
{
	ifstream right("error_right.txt");
	int label;
	while(right >> label) {
		r.insert(label);
	}
	string suffix[6] = {"4", "6", "7", "8", "10"};
	string prefix("res_e-");
	for(int i = 0; i < 5; i++) {
		string dirname = prefix + suffix[i];
		DIR* pDir = NULL;
		struct dirent* ent = NULL;
		pDir = opendir(dirname.c_str());
		if (pDir == NULL) {
			cout << "can not open dir " << dirname << endl;
			return 0;
		}
		string outfile = "error_" + suffix[i] + ".txt";
		ofstream err_out(outfile.c_str());
		string numfile = "num_" + suffix[i] + ".txt";
		ofstream num_out(numfile.c_str());
		set<int> nodup;
		while((ent = readdir(pDir)) != NULL) {
			if (ent->d_type == 8) {
				string s(ent->d_name);
				if (s.substr(0, 5) != "input") continue;
				string path = dirname + "/" + s;
				ifstream in(path.c_str());
				int num = 0;
				while(in >> label) {
					if (label == -1) break;
					if (r.find(label) != r.end()) num++;
					if (nodup.find(label) == nodup.end()) {
						err_out << label << endl;
						nodup.insert(label);
					}
				}
				in.close();
				if (num != 0) num_out << s << " " << num << endl;
			}
		}
		err_out.close();
		num_out.close();
		closedir(pDir);
		pDir = NULL;
	}

	for(int i = 0; i < 5; i++) {
		string infile = "error_" + suffix[i] + ".txt";
		ifstream errin(infile.c_str());
		vector<int> find_right;
		int cor = 0;
		int total = 0;
		while(errin >> label) {
			if (r.find(label) != r.end()) {
				cor++;
				find_right.push_back(label);
			}
			total++;
		}
		cout << "error threshold 1e+" << suffix[i] << " " << cor * 1.0 / total << endl;
		cout << "wrong operations:" << total - cor << endl;
		cout << "right operations " << find_right.size() << endl;
		cout << "total operations: " << total << endl;
		errin.close();
	}
	return 0;
}
