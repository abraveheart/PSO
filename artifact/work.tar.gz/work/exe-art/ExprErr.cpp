#include <stdio.h>
#include <gmp.h>
#include <mpfr.h>
#include <fstream>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <map>
#define u (1e-16)

using namespace std;

// arg1: input file name
// arg4: output file name

int main(int argc, char const *argv[])
{
	ifstream in(argv[1]);
	FILE * out = fopen(argv[2], "w+");
	string rel, ori, sha;
	string name;
	mpfr_t output, input, temp, dif;
	mpfr_init2(output, 200);
	mpfr_init2(input, 200);
	mpfr_init2(temp, 200);
	mpfr_init2(dif, 200);
	mpfr_set_d(input, 0, MPFR_RNDN);
	// map<int, double> funCalls;
	int lastNum = -1;
	while(in >> name) {
		if (name == "oneinstance") {
			fprintf(out, "%s\n", name.c_str());
			lastNum = -1;
			continue;
		}
		char **endptr = NULL;
		in >> ori >> sha >> rel;
		mpfr_strtofr(temp, rel.c_str(), endptr, 10, MPFR_RNDN);
		int pos = name.find_last_of("g");
		int number;
		if (name[name.size() - 1] == '_') {
			number = atoi(name.substr(pos + 1, name.size() - pos - 1).c_str());
			if (lastNum != -1 && number != lastNum) {
				// funCalls.insert(pair<int, double>(lastNum, mpfr_get_d(input, MPFR_RNDN)));
				mpfr_set_d(input, 0, MPFR_RNDN);
			}
			mpfr_max(input, input, temp, MPFR_RNDN);
			lastNum = number;
		} else {
			number = atoi(name.substr(pos + 1).c_str());
			if (mpfr_cmp_d(input, 0) == 0 && mpfr_cmp_d(temp, 0) != 0) {
				mpfr_set_d(input, u, MPFR_RNDN);
			}
			// if (lastNum != number) {
			// 	map<int, double>::iterator p = funCalls.find(number);
			// 	if (p != funCalls.end()) {
			// 		mpfr_set_d(input, p->second, MPFR_RNDN);
			// 		funCalls.erase(p);
			// 	}
			// }
			if(mpfr_cmp_d(input, 0) == 0 && mpfr_cmp_d(temp, 0) == 0) {
				fprintf(out, "%s\n%s\n%s\n0\n", name.c_str(), ori.c_str(), sha.c_str());
			} else {
				mpfr_sub(dif, temp, input, MPFR_RNDN);
				mpfr_div(output, dif, input, MPFR_RNDN);
				mpfr_abs(output, output, MPFR_RNDN);
				fprintf(out, "%s\n%s\n%s\n", name.c_str(), ori.c_str(), sha.c_str());
				mpfr_out_str(out, 10, 100, output, MPFR_RNDN);
				fprintf(out, "\n");

				mpfr_set_d(input, 0, MPFR_RNDN);
			}
			lastNum = -1;
		}
	}
	in.close();
	fclose(out);
	return 0;
}