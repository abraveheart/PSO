#include <iostream>
#include <unordered_map>
#include <map>
#include <unordered_set>
#include <string>
#include <cmath>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;

#ifndef DETECTION_H

#define DETECTION_H

#define OV_ZERO_BOUND (1e-9)

#define SV_ZERO_BOUND (1e-15)

#define MAX_NUM 50000

#define MAX_ITER 100

typedef int num_t;

class Count
{
public:
	Count() {
		errCnt = 0;
		osCnt = 0;
		totalCnt = 0;
	}
	int errCnt;
	int osCnt;
	int totalCnt;
};

class Detection
{
private:
	unordered_map<num_t, Count> errorMap;
	int avCnt[MAX_NUM * MAX_ITER];
	num_t maxIndex;
	vector<num_t> address;
	double errorThreshold;
	int execTimes;
	int lastInsert;
	unordered_set<int> reduced;

	void printAddress(double amountThreshold);

	num_t getIndex(int label, int cnt);

	int getLabel(num_t index);


public:
	Detection();
	~Detection();

	void init(double error, vector<int> v);

	void analyzeErrorMap(double amountThreshold);

	void detectStableError(char * fileName);

};

#endif


