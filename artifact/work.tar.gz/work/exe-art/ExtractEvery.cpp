#include <fstream>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <string.h>

using namespace std;

// Extract the original value, shadow value, and relative error of every computation
// arg1: input file name
// arg2: output file name

int main(int argc, char const *argv[])
{
	ifstream in(argv[1]);
	ofstream out(argv[2]);

	string str, last;
	while(in >> str) {
		if (str == "ORIGINAL:" || str == "VALUE:" || str == "RELATIVE") {
			if (str == "RELATIVE") in >> str;
			string value;
			in >> value;
			if (str == "ORIGINAL:") {
				out << last << endl;
			}
			out << value << endl;
		} else if (str == "oneinstance!") {
			out << "oneinstance" << endl;
		}
		// } else if (str[str.size() - 1] == '!') {
		// 	out << str.substr(0, str.size() - 1) << endl;
		// 	if (str != "oneinstance!") out << "noshadow" << endl;

		// }
		last = str;
	}
	in.close();
	out.close();
	return 0;
}