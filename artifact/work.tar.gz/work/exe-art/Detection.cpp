﻿#include <iostream>
#include <iomanip>
#include <map>
#include <string>
#include <cmath>
#include <vector>
#include <fstream>
#include <algorithm>
#include <cstring>
#include <sstream>
#include <queue>
#include "Detection.h"
using namespace std;

int mycount = 0;
vector<int> label;
Detection detect;

string toString(int a) {
	ostringstream ost;
	ost << a;
	string str(ost.str());
	return str;
}	

string toString(double a) {
	ostringstream ost;
	ost << a;
	string str(ost.str());
	return str;
}

Detection::Detection()
{
	execTimes = 0;
}

void Detection::init(double error, vector<int> v)
{
	errorThreshold = error;
	for(int i = 0; i < v.size(); i++) {
		reduced.insert(v[i]);
	}
}

num_t Detection::getIndex(int label, int cnt) {
	int temp = label * MAX_ITER + cnt;
	maxIndex = max(maxIndex, temp);
	return temp;
}

int Detection::getLabel(num_t index) {
	return index / MAX_ITER;
}

void Detection::printAddress(double amountThreshold)
{
	if (address.size() > 0)
	{
		mycount ++;
		cout << errorThreshold << " " << amountThreshold << endl;
	}
	sort(address.begin(), address.end());
	int errc, osc, totalc;
	errc = osc = totalc = 0;
	for(int i = 0; i < address.size(); i++) {	
		Count value = errorMap[address[i]];
		if (i > 0) {
			if (getLabel(address[i]) == getLabel(address[i - 1])) {
				errc += value.errCnt;
				osc += value.osCnt;
				totalc += value.totalCnt;
			} else {
				cout << getLabel(address[i - 1]) << " " << errc << " " << osc << " " << totalc << endl;
				label.push_back(getLabel(address[i - 1]));
				errc = value.errCnt;
				osc = value.osCnt;
				totalc = value.totalCnt;
			}
		} else {
			errc = value.errCnt;
			osc = value.osCnt;
			totalc = value.totalCnt;
		}
	}
	if (errc != 0) {
		cout << getLabel(address[address.size() - 1]) << " " << errc << " " << osc << " " << totalc << endl;
		label.push_back(getLabel(address[address.size() - 1]));
	}
	cout << endl;
}

void Detection::analyzeErrorMap(double amountThreshold)
{
	cout << "exec times:" << execTimes << endl;
	bool isAvailable = false;
	address.clear();
	memset(avCnt, 0, sizeof(avCnt)); // use as mark array
	for(auto it = errorMap.begin(); it != errorMap.end(); it ++)
	{
		Count value = it->second;
		
		if (value.totalCnt >= execTimes * 0 && 
			value.errCnt > (int)((double)value.totalCnt * amountThreshold))
		{
			if (reduced.find(getLabel(it->first)) != reduced.end()) continue;
			address.push_back(it->first);
		}
	}
	printAddress(amountThreshold);
}

void Detection::detectStableError(char * file_name) 
{
	ifstream in(file_name);
	string var_name;
	double ov;
	double sv;
	double error;
	bool first = true;
	memset(avCnt, 0, sizeof(int) * MAX_NUM);
	while(in >> var_name) 
	{
		if (var_name == "oneinstance") {
			execTimes++;
			first = true;
			memset(avCnt, 0, sizeof(int) * MAX_NUM);
			continue;
		}
		in >> ov >> sv >> error;
		if (first) {
			int pos = var_name.find_last_of("g");
			int number = atoi(var_name.substr(pos + 1).c_str());
			if (var_name == "b") continue;
			num_t index = getIndex(number, avCnt[number]);
			avCnt[number]++;
			if (reduced.find(number) != reduced.end()) {
				continue;
			}
			if (fabs(error) > errorThreshold)
			{
				auto it = errorMap.find(index);
				if (it == errorMap.end()) 
				{
					Count tuple;
					if (fabs(ov) < OV_ZERO_BOUND && fabs(sv) < SV_ZERO_BOUND){
                    		tuple.osCnt = 1;
					}
					tuple.errCnt = 1;
					tuple.totalCnt = 1;
					errorMap.insert(pair<num_t, Count>(index, tuple));
				}
				else
				{
					Count value = (*it).second;
					value.errCnt++;
					value.totalCnt++;
					if (fabs(ov) < OV_ZERO_BOUND && fabs(sv) < SV_ZERO_BOUND) {
                		value.osCnt++;
					}
					errorMap[index] = value;
				}
				first = false;
			} else {
				auto it = errorMap.find(index);
				if (it == errorMap.end()) 
				{
					Count tuple;
					tuple.totalCnt = 1;
					errorMap.insert(pair<num_t, Count>(index, tuple));
				}
				else
				{
					Count value = (*it).second;
					value.totalCnt++;
					errorMap[index] = value;
				}
			}
		}
	}
	in.close();
}

Detection::~Detection()
{
	errorMap.clear();
	address.clear();
}

int main(int argc,char *argv[])
{
	char output[100];
	output[0] = '\0';
	strcat(output, argv[1]);
	strcat(output, "_result_exc4_");
	strcat(output, argv[2]);
	freopen(output, "w", stdout);
	char input[100];
	input[0] = '\0';
	strcat(input, argv[1]);
	strcat(input, ".txt");
	mycount = 0;
	double error = atof(argv[3]);
	char output2[50];
	output2[0] = '\0';
	strcat(output2, "input_");
	strcat(output2, argv[1]);
	strcat(output2, ".txt");
	ifstream in(output2);
	vector<int> mark;
	while(1) {
		int num;
		in >> num;
		if (num == -1) break;
		mark.push_back(num);
	}
	in.close();
	detect.init(error, mark);
	detect.detectStableError(input);
	double amount = 0.7;
	detect.analyzeErrorMap(amount);
	fclose(stdout);
	if (mycount == 0) {
		ofstream temp("end");
		temp << endl;
		temp.close();
		return 0;
	}
    for(auto it = label.begin(); it != label.end(); it++) {
        mark.push_back(*it);
    }
	ofstream out(output2);
	for(int j = 0; j < 1000; j++) {
		for(int i = 0; i < mark.size(); i++) {
			out << mark[i] << " ";
		}
		out << -1 << endl;
	}
	out.close();
	return 0;
}
