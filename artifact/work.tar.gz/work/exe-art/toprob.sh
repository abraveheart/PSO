#!/bin/sh

cd ..
files=`ls *.c`
cd -

g++ toProb.cpp -std=c++0x -o toProb

echo $1

for file in $files
do
	func=${file%\.c}
	./toProb $func $1 $2
done
	
	
