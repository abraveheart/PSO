#!/bin/sh

USAGE="Usage: ./run.sh [-m dir_of_mpfr] [-r name_of_mpfr_library] 
[-g dir_of_gmp] [-p name_of_gmp_library] 
[-c dir_of_glibc] [-b name_of_glibc_library] 
[-e error_threshold]"

MPFRDIR="/usr/src/mpfr-build"
MPFRLIB="mpfr1"
GMPDIR="/usr/src/gmp-build2"
GMPLIB="gmp1"
GLIBCDIR="/usr/src/glibc-build-auto"
GLIBCLIB="m1"
ERRORTHRES=1e7

while getopts m:r:g:p:c:b:e:h OPTION ; do
	case "$OPTION" in
		m) MPFRDIR="$OPTARG" ;;
		r) MPFRLIB="$OPTARG" ;;
		g) GMPDIR="$OPTARG" ;;
		p) GMPLIB="$OPTARG" ;;
		c) GLIBCDIR="$OPTARG" ;;
		b) GLIBCLIB="$OPTARG" ;;
		e) ERRORTHRES="$OPTARG" ;;
		h) echo "$USAGE" ;
				exit 1;;
		\?) echo "$USAGE" ;
				exit 1;;
		esac
done

cp ../exe-files/*.c .
cp ../exe-files/*.h .
cp ../exe-input/*_t.txt .

echo $ERRORTHRES
filenames=`ls *.c`
g++ Detection.h Detection.cpp -std=c++0x -o Detection
g++ ExtractEvery.cpp -o ExtractEvery
g++ ExprErr.cpp -L$MPFRDIR/lib -l$MPFRLIB -L$GMPDIR/lib -l$GMPLIB -o ExprErr
prefix="input_"
suffix=".txt"
rel="_rel.txt"

rm *result*
rm end
rm tim${1}.log
touch tim${1}.log

for filename in $filenames
do
	begintime=`date +%s`
	cnt=0
	echo $filename
	execfile=${filename%\.c}
	outputfile=${execfile}${suffix}
	rel_file=${execfile}${rel}
	gcc $filename -g -L$GLIBCDIR/lib -l$GLIBCLIB -o $execfile
	inputfile=${prefix}${outputfile}
	echo 1000 -1 > temp.txt
	./input < temp.txt > $inputfile

	while [ ! -e "end" ]
	do	
		echo $cnt
		valgrind --tool=fpdebug ./$execfile > $outputfile 2>&1
		./ExtractEvery $outputfile $rel_file
		./ExprErr $rel_file $outputfile

		cnt=`expr $cnt + 1`
		./Detection $execfile $cnt $ERRORTHRES
		rm *shadow*
		rm *vcg
		rm *mean*
	done
	rm $outputfile
	rm $rel_file
	rm end
	rm $execfile
	rm temp.txt
	endtime=`date +%s`
	duration=`echo $endtime - $begintime | bc`
	echo $filename $duration >> tim${ERRORTHRES}.log
done

