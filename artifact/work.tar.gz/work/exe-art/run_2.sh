#!/bin/bash

values=(1e4 1e6 1e7 1e8 1e10 )
thres=(10000 1e+06 1e+07 1e+08 1e+10)
nums=(4 6 7 8 10)
with=res_e-
input=input_e-

for i in 0 1 2 3 4
do
	value=${values[$i]}
	num=${nums[$i]}
	withdir=${with}${num}
	inputdir=${input}${num}
	echo $num
	echo $value
	
	./run.sh -e $value
	mkdir $withdir
	mv *result* $withdir
	mv tim$value.log $withdir
	mkdir $inputdir
	mv input_*.txt $inputdir
	cd $withdir
	cp ../to* .
	./toprob.sh ${thres[$i]} 0.1
	cd ..
done

