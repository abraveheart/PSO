#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <string.h>
using namespace std;

string toString(int num)
{
	ostringstream oss;
	oss << num;
	string s(oss.str());
	return s;
}

int main(int argc,char *argv[])
{
	char filename[50];
	strcpy(filename, argv[1]);
	strcat(filename, "_result_exc4_");
	string temp;
	int cnt = 1;
	double zero_rate = atof(argv[3]);
	char inputFile[50];
	int leftReasons[1000], index = 0;
	int execTimes;
	while(1)
	{
		char tFile[50];
		tFile[0] = 0;
		strcat(tFile, filename);
		strcat(tFile, toString(cnt).c_str());
		ifstream in(tFile);
		if (!in) {
			break;
		}
		in >> temp;
		while (temp != "exec") in >> temp;
		int k;
		for(k = 0; k < 1; k++)
		{
			in >> temp;
			execTimes = atoi(temp.substr(6).c_str());
			in >> temp;
			if(strcmp(temp.c_str(), argv[2]) == 0)
			{
				in >> temp;
				int num;
                string reason;
                while (in >> reason && reason != "exec") {
				    int error;
				    in >> error;
				    int zero;
				    in >> zero;
				    in >> num;
				    if ((double)zero/(double)error < zero_rate) {
					    leftReasons[index] = atoi(reason.c_str());
					    index++;				
				    }
                }
				break;
			}
		}
		if (k == 1)
		{
			break;
		}
		cnt++;
	}
	strcpy(inputFile, "input_");
	strcat(inputFile, argv[1]);
	strcat(inputFile, ".txt");
	ofstream inputOut(inputFile);
	for(int i = 0; i < 1000; i++)
	{
		for(int j = 0; j < index; j++)
		{
			inputOut << leftReasons[j] << " ";
		}
		inputOut << "-1" << endl;
	}
	inputOut.close();
	return 0;
}
