#ifndef GLIBC_MATH_H
#define GLIBC_MATH_H

#include "/usr/src/glibc-build-auto/include/math.h"

#endif