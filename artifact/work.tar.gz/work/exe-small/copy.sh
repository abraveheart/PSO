#!/bin/sh

files=`ls *.c`

for file in $files
do
	cp ../$file .
done
