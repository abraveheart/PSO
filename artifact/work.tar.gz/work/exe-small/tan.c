#include "glibcmath.h"
#include <glibcFpdebug.h>
#include <stdio.h>

int main()
{
	double a;
	double c;
	FILE * input = fopen("tan_t.txt", "rt");
	while(fscanf(input, "%le", &a) != EOF) {
		VALGRIND_SET_SHADOW(&a);
		a = 0 - a;
		a = 0 - a;
		freopen("input_tan.txt", "r", stdin);
		double b = tan(a);
		printf("%.30lf\n", b);
		b = 0 - b;
		b = 0 - b;
		VALGRIND_PRINT_ERROR("b", &b);
		int oneinstance = 0;
		VALGRIND_PRINT_ERROR("oneinstance", &oneinstance);
		fclose(stdin);
	}
}
