#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	double a;
	double c;
	freopen("lround_t.txt", "r", stdin);
	while(scanf("%le", &a) != EOF) {
		long int b = lround(a);
		cout << b << endl;
	}
	fclose(stdin);
}
