#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	double a;
	double c;
	freopen("sincos_t.txt", "r", stdin);
	while(scanf("%le", &a) != EOF) {
		double si, ci;
		sincos(a, &si, &ci);
		cout << setprecision (59) << scientific << si << endl;
		cout << setprecision (59) << scientific << ci << endl;
	}
	fclose(stdin);
}
