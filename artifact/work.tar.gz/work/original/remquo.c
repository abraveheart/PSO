#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	double a;
	double c;
	int quo;
	freopen("remquo_t.txt", "r", stdin);
	while(scanf("%le %le", &a, &c) != EOF) {
		double b = remquo(a, c, &quo);
		cout << setprecision (59) << scientific << b << endl;
	}
	fclose(stdin);
}
