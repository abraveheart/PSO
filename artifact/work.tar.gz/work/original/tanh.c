#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	double a;
	double c;
	freopen("tanh_t.txt", "r", stdin);
	while(scanf("%le", &a) != EOF) {
		double b = tanh(a);cout << setprecision (59) << scientific << b<< endl;
	}
	fclose(stdin);
}
