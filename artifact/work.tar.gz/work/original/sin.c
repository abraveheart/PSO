#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	double a;
	double c;
	freopen("sin_t.txt", "r", stdin);
	while(scanf("%le", &a) != EOF) {
		double b = sin(a);cout << setprecision (59) << scientific << b<< endl;
	}
	fclose(stdin);
}
