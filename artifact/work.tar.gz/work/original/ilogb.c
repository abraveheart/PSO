#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	double a;
	double c;
	freopen("ilogb_t.txt", "r", stdin);
	while(scanf("%le", &a) != EOF) {
		if (a == 0) continue;
		int b = ilogb(a);
		cout << b << endl;
	}
	fclose(stdin);
}
