#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	double a;
	double c;
	freopen("llround_t.txt", "r", stdin);
	while(scanf("%le", &a) != EOF) {
		long long int b = llround(a);
		cout << b << endl;
	}
	fclose(stdin);
}
