#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	double a;
	long int c;
	freopen("scalbln_t.txt", "r", stdin);
	while(scanf("%le %ld", &a, &c) != EOF) {
		double b = scalbln(a, c);
		cout << setprecision (59) << scientific << b << endl;
	}
	fclose(stdin);
}
