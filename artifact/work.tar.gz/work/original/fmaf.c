#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	float a;
	float c;
	float d;
	freopen("fmaf_t.txt", "r", stdin);
	while(scanf("%e %e %e", &a, &c, &d) != EOF) {
		float b = fmaf(a,c,d);
		cout << setprecision (59) << scientific << b << endl;
	}
	fclose(stdin);
}
