#!/bin/sh

#Go into the directory where you place glibc-exe

filenames=`ls *.c`
suffix=".txt"

for filename in $filenames
do
	echo $filename
	execfile=${filename%\.c}
	outputfile=${execfile}_low${suffix}
	g++ $filename -g -L/usr/src/glibc-std/lib -lm3 -o $execfile
	./$execfile > $outputfile
done


