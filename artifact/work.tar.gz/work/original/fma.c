#include "/usr/src/glibc-build/include/math.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;

int main()
{
	double a;
	double c;
	double d;
	freopen("fma_t.txt", "r", stdin);
	while(scanf("%le %le %le", &a, &c, &d) != EOF) {
		double b = fma(a, c, d);
		cout << setprecision (59) << scientific << b << endl;
	}
	fclose(stdin);
}
