#error "The correct implementation must be chosen based on the `intmax_t' type"
