#define USE_WIDE_CHAR	1
#include "grouping.c"
