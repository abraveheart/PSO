/* Empty.  Not needed unless ldbl support is in. */
