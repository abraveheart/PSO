#include <wchar.h>
#include <wctype.h>
#include <stddef.h>
ptrdiff_t i;

int
main (void)
{
  return 0;
}
