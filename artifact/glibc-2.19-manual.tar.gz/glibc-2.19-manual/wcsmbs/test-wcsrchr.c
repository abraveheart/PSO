#define WIDE 1
#include "../string/test-strrchr.c"
