#define WIDE 1
#include "../string/test-memcmp.c"
