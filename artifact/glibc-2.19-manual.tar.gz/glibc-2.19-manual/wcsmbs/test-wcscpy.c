#define WIDE 1
#include "../string/test-strcpy.c"
