/* Empty file expected by glibc's standard build rules for
   executables.  */
